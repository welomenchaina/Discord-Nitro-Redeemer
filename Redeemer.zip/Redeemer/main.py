import os
import time
import colorama
import selenium
import traceback
import platform
import sys
import ctypes
import hashlib
import undetected_chromedriver as uc
from pystyle import Colors, Colorate
from time import sleep
from datetime import datetime
from colorama import Fore, Back, Style


from sys import exit
from colorama import init, Fore
from selenium.webdriver.common.by import By
from multiprocessing import freeze_support
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC



import sys
import time
import platform
import os
import hashlib
from time import sleep
from datetime import datetime

import sys
import subprocess




ctypes.windll.kernel32.SetConsoleTitleW("                                                                                                                                                     ")

headless = False



import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)


def activate_acc(token, link, number, expiry, cvc):
    try:
        chrome_options = uc.ChromeOptions()
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument("--log-level=3")
        chrome_options.headless = headless
        emulator = uc.Chrome(options=chrome_options)
        emulator.get("https://discord.com/login")
        emulator.execute_script(
            "function login_with_token(t) {setInterval(() => {document.body.appendChild(document.createElement `iframe`).contentWindow.localStorage.token = `\"${t}\"`}, 50);setTimeout(() => {location.reload();}, 1500);}\nlogin_with_token(\"" + token + "\")")
        time.sleep(6)
        emulator.get(link)
        time.sleep(1)
        try:
            WebDriverWait(emulator, 10).until(
                EC.element_to_be_clickable(
                    (By.XPATH,
                     "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/form/div[2]/button"))).click()
        except selenium.common.exceptions.TimeoutException:
            if "This nitro code is not working" in emulator.page_source:
                print(f"{Fore.RED}[!] {link} This nitro code is not working{Fore.RESET}")
                emulator.close()
                return "link"
            elif "This Nitro Code Has Been Used Before" in emulator.page_source:
                print(f"{Fore.RED}[!] {link} This Nitro Code Has Been Used Before{Fore.RESET}")
                emulator.close()
                return "link"
            elif "Looks like you already have Nitro. Sorry, promotions are for new subscribers only. You can give your link to a friend and send him 3 months of free Nitro." in emulator.page_source:
                print(f"{Fore.RED}[!] {token} has nitro already{Fore.RESET}")
                emulator.close()
                return "token"
            elif "QR-Code" in emulator.page_source:
                print(f"{Fore.RED}[!] {token} This token is invalid (back to QR CODE){Fore.RESET}")
                emulator.close()
                return "token"
            else:
                emulator.get(link)
                time.sleep(5)
                try:
                    emulator.find_element(By.XPATH,
                                          "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div[3]/div").click()
                except selenium.common.exceptions.NoSuchElementException:
                    print(f"{Fore.RED}[!] Seems like the promo link is invalid removing the invalid link restart the programm (couldnt start the promo activation){Fore.RESET}")
                    emulator.close()
                    return "link"
                
        time.sleep(1.5)
        try:
            try:
                WebDriverWait(emulator, 7).until(EC.element_to_be_clickable((By.XPATH,
                                                                             "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div[3]/div"))).click()
                WebDriverWait(emulator, 7).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "/html/body/div[1]/div[2]/div/div[3]/div/div[1]/div[2]"))).click()
            except (selenium.common.exceptions.NoSuchElementException, selenium.common.exceptions.TimeoutException):
                WebDriverWait(emulator, 8).until(EC.element_to_be_clickable((By.XPATH,
                                                                             "/html/body/div[1]/div[2]/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div[4]/div/label/input"))).click()
                time.sleep(0.2)
                WebDriverWait(emulator, 8).until(EC.element_to_be_clickable((By.XPATH,
                                                                             "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div/div[2]/div/div[1]/button[1]"))).click()
                time.sleep(5)
                emulator.refresh()
                try:
                    WebDriverWait(emulator, 4).until(EC.visibility_of_element_located((By.XPATH,
                                                                                       "/html/body/div[1]/div[2]/div/div/div/div/div/div/div/form/div[2]/button"))).click()
                except selenium.common.exceptions.TimeoutException:
                    WebDriverWait(emulator, 4).until(EC.visibility_of_element_located((By.XPATH,
                                                                                       "/html/body/div[1]/div[2]/div/div/div/div/div/div/div/form/div[2]/div/button"))).click()
                WebDriverWait(emulator, 8).until(EC.element_to_be_clickable((By.XPATH,
                                                                             "/html/body/div[1]/div[2]/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div[4]/div/label/input"))).click()
                time.sleep(0.2)
                WebDriverWait(emulator, 8).until(EC.element_to_be_clickable((By.XPATH,
                                                                             "/html/body/div[1]/div[2]/div/div/div/div/div/div/div/form/div[2]/button"))).click()
                i = 0
                while i < 25:
                    time.sleep(2)
                    i += 1
                    if "svgBorder-2bdygG" in emulator.page_source:
                        print(f'{Fore.GREEN}[+] Nitro Token Successfully Activated {str(token)}{Fore.RESET}')
                        emulator.close()
                        return "successful"
                    elif "you can't use that code" in emulator.page_source:
                        print(f"{Fore.RED}[!] Cannot aktivate promo idk why dm the owner{Fore.RESET}")
                        try:
                            emulator.close()
                        except UnboundLocalError:
                            pass
                        return "restart"
                print(f"{Fore.RED}[!] {str(token)} (RESTARTED) Cannot aktivate promo idk why dm the owner{Fore.RESET}")
                return
            WebDriverWait(emulator, 7).until(EC.element_to_be_clickable((By.XPATH,
                                                                         "/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[2]/div/div[1]/button[1]"))).click()
            frame = WebDriverWait(emulator, 6).until(EC.visibility_of_element_located((By.XPATH,
                                                                                       "/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[1]/div/div[2]/div/div[3]/div/iframe")))
            emulator.switch_to.frame(frame)
            WebDriverWait(emulator, 6).until(EC.visibility_of_element_located((By.NAME, "cardnumber"))).send_keys(
                int(number))
            emulator.switch_to.default_content()
            frame = WebDriverWait(emulator, 6).until(EC.visibility_of_element_located((By.XPATH,
                                                                                       "/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[2]/div[1]/div[2]/div/div[2]/div/iframe")))
            emulator.switch_to.frame(frame)
            WebDriverWait(emulator, 6).until(EC.visibility_of_element_located((By.NAME, "exp-date"))).send_keys(
                str(expiry))
            emulator.switch_to.default_content()
            frame = WebDriverWait(emulator, 6).until(EC.visibility_of_element_located((By.XPATH,
                                                                                       "/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[2]/div[2]/div[2]/div/div[2]/div/iframe")))
            emulator.switch_to.frame(frame)
            WebDriverWait(emulator, 6).until(EC.visibility_of_element_located((By.NAME, "cvc"))).send_keys(str(cvc))
            emulator.switch_to.default_content()
            WebDriverWait(emulator, 6).until(EC.visibility_of_element_located((By.NAME, "name"))).send_keys(
                "mr han")
            WebDriverWait(emulator, 6).until(EC.element_to_be_clickable(
                (By.XPATH,
                 "/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[2]/button[1]"))).click()
            WebDriverWait(emulator, 9).until(EC.visibility_of_element_located((By.NAME,
                                                                               "line1"))).send_keys(
                "yo mom house 69")
            WebDriverWait(emulator, 9).until(EC.visibility_of_element_located((By.NAME,
                                                                               "city"))).send_keys(
                "ClownHouse")

            try:
                WebDriverWait(emulator, 4).until(EC.visibility_of_element_located((By.NAME,
                                                                                   "postalCode"))).send_keys(
                    "34890")
            except selenium.common.exceptions.TimeoutException:
                try:
                    WebDriverWait(emulator, 4).until(EC.visibility_of_element_located((By.XPATH,
                                                                                       "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div/div[5]/div[2]/div[2]/div/input"))).send_keys(
                        "140301")
                except (selenium.common.exceptions.TimeoutException, selenium.common.exceptions.NoSuchElementException):
                    try:
                        WebDriverWait(emulator, 4).until(EC.visibility_of_element_located((By.XPATH,
                                                                                           "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div/div[5]/div[2]/div[2]/div/input"))).send_keys(
                            "85143")
                    except selenium.common.exceptions.TimeoutException:
                        WebDriverWait(emulator, 9).until(EC.visibility_of_element_located((By.XPATH,
                                                                                           "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div/div[5]/div[2]/div[2]/div/input"))).send_keys(
                            "85143")

            try:
                WebDriverWait(emulator, 2).until(EC.visibility_of_element_located((By.NAME,
                                                                                   "state"))).send_keys(
                    "Punjab")
            except selenium.common.exceptions.TimeoutException:
                try:
                    WebDriverWait(emulator, 5).until(EC.element_to_be_clickable(
                        (By.XPATH,
                         "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div/div[5]/div[1]/div[2]/div/div[1]"))).click()
                    WebDriverWait(emulator, 5).until(EC.element_to_be_clickable(
                        (By.XPATH,
                         "/html/body/div[1]/div[2]/div/div[3]/div/div/div/li[1]"))).click()
                except selenium.common.exceptions.TimeoutException:
                    pass

            try:
                WebDriverWait(emulator, 5).until(EC.element_to_be_clickable(
                    (By.XPATH,
                     "/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[2]/button[1]"))).click()
            except selenium.common.exceptions.TimeoutException:
                WebDriverWait(emulator, 4).until(EC.visibility_of_element_located((By.XPATH,
                                                                                   "/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div[4]/div/label/input"))).send_keys(
                    "T5J 2R4")
                WebDriverWait(emulator, 4).until(EC.element_to_be_clickable(
                    (By.XPATH,
                     "/html/body/div[1]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[2]/button[1]"))).click()

        except selenium.common.exceptions.TimeoutException as e:
            print(f"{Fore.RED}[!] Something went wrong while confirming the card data deleting card from txt{Fore.RESET}")
            open("debug.txt", "w").write(
                str(traceback.print_exc(file=open("debug.txt", "w", encoding="UTF-8"))) + "\n" + str(
                    e.__class__.__name__))
            time.sleep(2)
            emulator.close()
            return "unknown"

        time.sleep(5)
        WebDriverWait(emulator, 6).until(EC.element_to_be_clickable((By.XPATH,
                                                                     "/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div[4]/div/label/div[1]"))).click()
        WebDriverWait(emulator, 6).until(EC.element_to_be_clickable((By.XPATH,
                                                                     "/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/form/div[2]/button[1]"))).click()

        i = 0
        while i < 25:
            time.sleep(2)
            i += 1
            if "svgBorder-2bdygG" in emulator.page_source:
                print(f"{Fore.GREEN}[+] {str(token)} added nitro{Fore.RESET}")
                emulator.close()
                return "successful"
            elif "code Not used!" in emulator.page_source:
                print(Colors.red + f'{Fore.RED}[!] Card Error while adding nitro{Fore.RESET}')
                try:
                    emulator.close()
                except UnboundLocalError:
                    pass
                return "restart"

        emulator.refresh()
        try:
            WebDriverWait(emulator, 4).until(EC.visibility_of_element_located((By.XPATH,
                                                                               "/html/body/div[1]/div[2]/div/div/div/div/div/div/div/form/div[2]/button"))).click()
        except selenium.common.exceptions.TimeoutException:
            WebDriverWait(emulator, 4).until(EC.visibility_of_element_located((By.XPATH,
                                                                               "/html/body/div[1]/div[2]/div/div/div/div/div/div/div/form/div[2]/button"))).click()
        WebDriverWait(emulator, 8).until(EC.visibility_of_element_located((By.XPATH,
                                                                           "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div/div/div/div/form/div[1]/div[2]/div/div/div/div/div[1]/div[4]/div/label/input"))).click()
        time.sleep(0.2)
        WebDriverWait(emulator, 8).until(EC.visibility_of_element_located((By.XPATH,
                                                                           "/html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/form/div[2]/button[1]"))).click()
        i = 0
        while i < 25:
            time.sleep(2)
            i += 1
            if "svgBorder-2bdygG" in emulator.page_source:
                print(f'[!] {str(token)} [+] {str(token)} Added nitro')
                emulator.close()
                return "successful"
            elif "Code Unavailable !" in emulator.page_source:
                print(f"{Fore.RED}[!] vcc error{Fore.RESET}")
                try:
                    emulator.close()
                except UnboundLocalError:
                    pass
                return "restart"
        print(Colors.red + f'{Fore.RED}[!] {str(token)} Sorry, Couldnt Add Nitro{Fore.RESET}')
    except Exception as e:
        print(f"{Fore.RED}[!] Error seems like card got rejected{Fore.RESET}")
        open("debug.txt", "w").write(
            str(traceback.print_exc(file=open("debug.txt", "w", encoding="UTF-8"))) + "\n" + str(e))
        emulator.close()
        sys.exit
from colorama import Fore, Back, Style

def logo():
    colorama.deinit()
    os.system("mode con cols=135 lines=30")
    os.system('cls' if os.name == 'nt' else 'clear')
    print(Fore.YELLOW  + """
    
    
                                                  
      ____                   __  ____             
     / __ )____  ____  _____/ /_/ __ )____ ___  __
    / __  / __ \/ __ \/ ___/ __/ __  / __ `/ / / /
   / /_/ / /_/ / /_/ (__  ) /_/ /_/ / /_/ / /_/ / 
  /_____/\____/\____/____/\__/_____/\__,_/\__, /  
                                         /____/   Nitro Redeemer
    """+ Style.RESET_ALL)
    colorama.init(autoreset=True)

if __name__ == '__main__':
    freeze_support()
    logo()
    if not os.path.exists("./input"):
        os.makedirs("./input")
    if not os.path.isfile("./input/tokens.txt") or not os.path.isfile("./input/nitro.txt") or not os.path.isfile("./input/cards.txt"):
        print(f"{Fore.GREEN}[+] Files Not Found, Creating Now!{Fore.RESET}")
        open("./input/tokens.txt", "w", encoding="UTF-8")
        open("./input/nitro.txt", "w", encoding="UTF-8")
        open("./input/cards.txt", "w", encoding="UTF-8").write("number:expiry:cvc")
        print(f"{Fore.YELLOW}[+] Press Enter to continue{Fore.RESET}", end="")
        input()



    tokens = open("./input/tokens.txt", "r", encoding="UTF-8").read().splitlines()
    links = open("./input/nitro.txt", "r", encoding="UTF-8").read().splitlines()
    ccs = open("./input/cards.txt", "r", encoding="UTF-8").read().splitlines()

    if not tokens or not links or not ccs:
        print(f"{Fore.RED}[!] No Token Or Nitro Code Found!{Fore.RESET}")

        print(f"{Fore.YELLOW}[+] Press Enter to Close...{Fore.RESET}", end="")
        input()
        exit(0)

    if len(links) < len(tokens):
        print(f'\n\n{Fore.RED}[!] {len(links)} Promo code {len(tokens)} tokens.{Fore.RESET}')
        tokens = tokens[0:len(links)]

    from colorama import Fore

    print(f"{Fore.YELLOW}[?] How Many Numbers Should One Card Be Used?{Fore.RESET}", end=" ")
    card_uses = int(input())

    print(f"{Fore.GREEN}[+] {len(tokens)} Tokens Working...{Fore.RESET}")
    successful = 0
    current_link = 0
    current_card = 0
    current_card_uses = 0
    for current_token in tokens:
        failsafe_token = current_token
        try:
            current_token = current_token.split(":")[2]
        except IndexError:
            pass 
        while True:
            result = activate_acc(current_token, links[current_link], ccs[current_card].split(":")[0],
                                  ccs[current_card].split(":")[1], ccs[current_card].split(":")[2])
            if result == "link":
                temp_links = open("./input/nitro.txt", "r", encoding="UTF-8").read().splitlines()
                try:
                    temp_links.remove(links[current_link])
                except ValueError:
                    pass
                temp_file = open("./input/nitro.txt", "w", encoding="UTF-8")
                for link in temp_links:
                    temp_file.write(link + "\n")
                temp_file.close()
                current_link += 1
            elif result == "token":
                temp_tokens = open("./input/tokens.txt", "r", encoding="UTF-8").read().splitlines()
                try:
                    temp_tokens.remove(current_token)
                except ValueError:
                    temp_tokens.remove(failsafe_token)
                temp_file = open("./input/tokens.txt", "w", encoding="UTF-8")
                for token in temp_tokens:
                    temp_file.write(token + "\n")
                temp_file.close()
                break
            elif result == "unknown":
                break
            elif result == "restart":
                pass
            elif result == "successful":
                if not os.path.isfile(".nitro-tokens.txt"):
                    open("nitro-tokens.txt", "w")
                temp_tokens = open("nitro-tokens.txt", "r", encoding="UTF-8").read().splitlines()
                temp_tokens.append(current_token)
                temp_file = open("nitro-tokens.txt", "w", encoding="UTF-8")
                for token in temp_tokens:
                    temp_file.write(token + "\n")
                temp_file.close()
                temp_tokens = open("./input/tokens.txt", "r", encoding="UTF-8").read().splitlines()
                try:
                    temp_tokens.remove(current_token)
                except ValueError:
                    temp_tokens.remove(failsafe_token)
                temp_file = open("./input/tokens.txt", "w", encoding="UTF-8")
                for token in temp_tokens:
                    temp_file.write(token + "\n")
                temp_file.close()
                temp_links = open("./input/nitro.txt", "r", encoding="UTF-8").read().splitlines()
                temp_links.remove(links[current_link])
                temp_file = open("./input/nitro.txt", "w", encoding="UTF-8")
                for link in temp_links:
                    temp_file.write(link + "\n")
                temp_file.close()
                successful += 1
                break
            else:
                break
        if result == "token":
            continue
        current_link += 1
        current_card_uses += 1
        if current_card_uses == card_uses:
            current_card_uses = 0
            temp_cards = open("./input/cards.txt", "r", encoding="UTF-8").read().splitlines()
            temp_cards.remove(ccs[current_card])
            temp_file = open("./input/cards.txt", "w", encoding="UTF-8")
            for card in temp_cards:
                temp_file.write(card + "\n")
            temp_file.close()
            current_card += 1

    if successful == 0:
        print(f'{Fore.RED}[!] Unfortunately Nitro Could Not Activate Account see the errors{Fore.RESET}')
    else:
        print(f"{Fore.GREEN}[+] Successfully Activated {successful} Token Nitro{Fore.RESET}")
    print(f"{Fore.YELLOW}[+] Press Enter to close...{Fore.RESET}", end="")
    input()
    exit(0)